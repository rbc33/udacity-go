Endpoints example
GET http://localhost:3000/customers(opens in a new tab)
GET http://localhost:3000/customers/1(opens in a new tab)
POST http://localhost:3000/customers(opens in a new tab) json data :- { "name": "Testing", "email": "test@yahoo.com(opens in a new tab)", "phone": "+14155552671", "role": "test Customer", "contacted": true }
PUT http://localhost:3000/customers/3(opens in a new tab) json data :- { "name": "Testing_update", "email": "test_update@yahoo.com(opens in a new tab)", "phone": "+14155552671", "role": "Update Customer", "contacted": true }
DELETE http://localhost:3000/customers/3(opens in a new tab)
